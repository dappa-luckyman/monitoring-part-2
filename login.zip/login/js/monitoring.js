$(document).ready(function () {
    console.log("jquery let's go...");

    $("#summary,#chart").hide()
});