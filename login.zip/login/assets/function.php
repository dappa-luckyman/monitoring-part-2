<?php
class klass_air{
    function koneksi() {
        $koneksi=mysqli_connect("localhost", "admin", "admin1234", "db_monitoring2");
        return $koneksi;
    }

    function dt_user($sesi_user) 
    {
        $q=mysqli_query($this->koneksi(),"SELECT nama,alamat,level FROM user1 WHERE username='$sesi_user'");
        $d=mysqli_fetch_row($q);
        return $d;
    }
}

?>