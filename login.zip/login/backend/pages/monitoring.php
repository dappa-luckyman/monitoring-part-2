<?php
// Ambil data dari database
$result = mysqli_query($koneksi, "SELECT * FROM sensor_data ORDER BY waktu DESC LIMIT 10");

// Ambil data terakhir untuk ditampilkan di kartu
$latestData = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT * FROM sensor_data ORDER BY waktu DESC LIMIT 1"));
?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Monitoring</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Sensor Parameters</li>
    </ol>

    <!-- Tabel Riwayat Data -->
   <!-- <table class="table table-striped"> -->
        <!-- <thead>
            <tr>
                <th>Waktu</th>
                <th>Suhu (°C)</th>
                <th>Kelembaban Udara (%)</th>
                <th>Kelembaban Tanah (%)</th>
            </tr>
        </thead> -->
        <!--<tbody> -->
            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <?php error_reporting(E_ERROR | E_PARSE); ?>
                    <td><?= $row['']; ?></td>
                    <td><?= $row['']; ?></td>
                    <td><?= $row['']; ?></td>
                    <td><?= $row['']; ?></td>
                </tr>
            <?php } ?>
        </tbody>
    </table>

    <!-- Kartu Monitoring -->
    <div class="row">
        <div class="col-xl-4">
            <div class="card mb-4">
                <div class="card-header"><i class="fas fa-water me-1"></i> Kelembaban Tanah</div>
                <div class="card-body text-center">
                    <h2 id="soil-moisture">--</h2>
                    <p>Persentase (<?= $latestData['kelembaban_tanah'] ?? '--'; ?> %)</p>
                    <canvas id="soilMoistureChart" width="100%" height="40"></canvas>
                </div>
            </div>
        </div>
        <div class="col-xl-4">
            <div class="card mb-4">
                <div class="card-header"><i class="fas fa-temperature-high me-1"></i> Suhu</div>
                <div class="card-body text-center">
                    <h2 id="temperature">--</h2>
                    <p>Celsius (<?= $latestData['suhu'] ?? '--'; ?> °C)</p>
                    <canvas id="temperatureChart" width="100%" height="40"></canvas>
                </div>
            </div>
        </div>
        <div class="col-xl-4">
            <div class="card mb-4">
                <div class="card-header"><i class="fas fa-wind me-1"></i> Kualitas Udara</div>
                <div class="card-body text-center">
                    <h2 id="air-quality">--</h2>
                    <p>PPM</p>
                    <canvas id="airQualityChart" width="100%" height="40"></canvas>
                </div>
            </div>
        </div>
    </div>

    <!-- Grafik Real-time -->
    <div class="row">
        <div class="col-xl-12">
            <div class="card mb-4">
                <div class="card-header"><i class="fas fa-chart-line me-1"></i> Grafik Real-time</div>
                <div class="card-body">
                    <canvas id="realTimeChart" width="100%" height="40"></canvas>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript untuk update data realtime -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    function updateSensorValues() {
        fetch('get_sensor_data.php')
            .then(response => response.json())
            .then(data => {
                document.getElementById('soil-moisture').textContent = data.soil_moisture ?? '--';
                document.getElementById('temperature').textContent = data.temperature ?? '--';
                document.getElementById('air-quality').textContent = data.air_quality ?? '--';

                // Update grafik jika ada Chart.js di-setup
                // e.g., updateSoilChart(data.soil_moisture);
            })
            .catch(error => console.error('Gagal mengambil data sensor:', error));
    }

    // Update setiap 5 detik
    setInterval(updateSensorValues, 5000);
});

</script>
