<?php
include 'koneksi.php';

$suhu = $_POST['suhu'] ?? null;
$kualitas = $_POST['kualitas_udara'] ?? null;

if ($suhu !== null && $kualitas !== null) {
    $sql = "INSERT INTO sensor_data (suhu, kualitas_udara, waktu)
            VALUES ('$suhu', '$kualitas', NOW())";
    if (mysqli_query($koneksi, $sql)) {
        echo "OK";
    } else {
        echo "Gagal simpan: " . mysqli_error($koneksi);
    }
} else {
    echo "Data tidak lengkap.";
}
?>
